import json
import random
import time
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from utils.helper import parse_price

from .base_scraper import BaseScraper


class DiorScraper(BaseScraper):
    BASE_URL = "https://www.dior.com"

    def _before_navigate(self, scraping_settings: dict) -> None:
        time.sleep(random.uniform(1.0, 3.0))

    def extract_products_from_html(self, html: str, category_name: str, category_url: str) -> list[dict]:
        products = self._extract_products_from_next_data(html, category_name)
        if not products:
            products = self._extract_products_from_json_ld(html, category_name)
        if not products:
            products = self._extract_products_from_selectors(html, category_name, category_url)
        return self._deduplicate_by_url(products)

    def _extract_products_from_next_data(self, html: str, category_name: str) -> list[dict]:
        soup = BeautifulSoup(html, "html.parser")
        script = soup.find("script", id="__NEXT_DATA__")
        if not script:
            return []

        try:
            data = json.loads(script.string)
            dictionnary = (
                data.get("props", {})
                .get("pageProps", {})
                .get("queriesProductsDictionnary", {})
            )
        except (json.JSONDecodeError, AttributeError, KeyError):
            return []

        products = []
        for key in dictionnary:
            for hit in (dictionnary[key] or {}).get("hits", []):
                name = hit.get("title") or hit.get("titleInt") or "N/A"
                price_data = hit.get("price", {})
                price = price_data.get("value") if isinstance(price_data, dict) else None

                sku = hit.get("sku") or hit.get("style_color_ref") or ""

                # color.label_int(영문) 우선, 없으면 color.label(한글), 없으면 subtitle
                color_data = hit.get("color", {})
                if isinstance(color_data, dict):
                    colors = color_data.get("label_int") or color_data.get("label") or ""
                else:
                    colors = hit.get("subtitle") or ""

                # 소재
                material_data = hit.get("material", {})
                material = ""
                if isinstance(material_data, dict):
                    material = material_data.get("label_int") or material_data.get("label") or ""

                # 사이즈 (variants / variantsWithStocks)
                sizes = self._extract_sizes_from_hit(hit)

                # 카테고리 페이지 리스팅 이미지 URL
                listing_image = (
                    (hit.get("views") or {})
                    .get("listing") or {}
                )
                listing_image = (
                    (listing_image.get("images") or {})
                    .get("r9x10detail") or {}
                )
                listing_image = listing_image.get("uri", "")

                url_path = (
                    ((hit.get("attributes") or {}).get("productLink") or {}).get("uri", "")
                )
                full_url = urljoin(self.BASE_URL, url_path) if url_path else ""

                products.append({
                    "category": category_name,
                    "name": str(name).strip(),
                    "price": price,
                    "url": full_url,
                    "reference": str(sku).strip(),
                    "colors": str(colors).strip(),
                    "material": str(material).strip(),
                    "sizes": sizes,
                    "image_urls": listing_image,
                })

        return products

    def _extract_sizes_from_hit(self, hit: dict) -> str:
        """카테고리 hit 객체의 variants / variantsWithStocks에서 사이즈를 추출합니다."""
        for key in ("variantsWithStocks", "variants"):
            items = hit.get(key, [])
            if not isinstance(items, list) or not items:
                continue
            sizes = []
            for item in items:
                if not isinstance(item, dict):
                    continue
                size = (
                    item.get("size") or item.get("sizeLabel")
                    or item.get("value") or item.get("label")
                    or item.get("name")
                )
                if size:
                    sizes.append(str(size))
            if sizes:
                return ", ".join(dict.fromkeys(sizes))
        return ""

    # ── 상세 페이지 ────────────────────────────────────────────────────────────

    def _parse_detail_from_next_data(self, html: str) -> dict:
        soup = BeautifulSoup(html, "html.parser")
        script = soup.find("script", id="__NEXT_DATA__")
        if not script:
            return {}

        try:
            data = json.loads(script.string)
            page_props = (data.get("props") or {}).get("pageProps") or {}
        except (json.JSONDecodeError, AttributeError):
            return {}

        product = self._find_detail_product(page_props)

        if not product:
            # Dior 특화: queriesProductsDictionnary 첫 번째 히트에서 추출
            dictionnary = page_props.get("queriesProductsDictionnary") or {}
            for key in dictionnary:
                hits = (dictionnary[key] or {}).get("hits", [])
                if hits:
                    product = hits[0]
                    break

        if not product:
            return {}

        return {
            "description": self._extract_description(product),
            "sizes": self._extract_sizes(product),
            "image_urls": self._extract_image_urls(product),
            "store_inventory": "",
        }

    # ── 카테고리 목록 추출 ─────────────────────────────────────────────────────

    def _extract_products_from_selectors(self, html: str, category_name: str, category_url: str) -> list[dict]:
        selectors = self.config["selectors"]
        soup = BeautifulSoup(html, "html.parser")
        cards = soup.select(selectors["product_card"])

        products = []
        for card in cards:
            name_tag = card.select_one(selectors.get("name", ""))
            price_tag = card.select_one(selectors.get("price", ""))
            link_tag = card.select_one(selectors.get("link", ""))

            href = ""
            if link_tag and link_tag.has_attr("href"):
                href = urljoin(category_url, link_tag["href"])

            products.append({
                "category": category_name,
                "name": name_tag.get_text(strip=True) if name_tag else "N/A",
                "price": parse_price(price_tag) if price_tag else None,
                "url": href,
                "reference": "",
                "colors": "",
            })

        return products
