import json
import random
import re
import time
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from utils.helper import parse_price

from .base_scraper import BaseScraper


class LvScraper(BaseScraper):
    BASE_URL = "https://kr.louisvuitton.com"

    def extract_products_from_html(self, html: str, category_name: str, category_url: str) -> list[dict]:
        # 셀렉터 기반 추출을 최우선으로 시도 (LV HTML 구조가 안정적일 때 가장 정확)
        products = self._extract_products_from_selectors(html, category_name, category_url)
        if not products:
            products = self._extract_products_from_next_data(html, category_name)
        if not products:
            products = self._extract_products_from_json_ld(html, category_name)
        return self._deduplicate_by_url(products)

    # ── 상세 페이지 ────────────────────────────────────────────────────────────

    def _detail_wait_range(self) -> tuple[float, float]:
        return (2.0, 4.0)

    def _parse_detail_from_next_data(self, html: str) -> dict:
        soup = BeautifulSoup(html, "html.parser")
        script = soup.find("script", id="__NEXT_DATA__")
        if not script:
            return {}

        try:
            data = json.loads(script.string)
            page_props = data.get("props", {}).get("pageProps", {})
        except (json.JSONDecodeError, AttributeError):
            return {}

        product = self._find_detail_product(page_props)
        if not product:
            return {}

        # LV는 sizes가 skus[].size 패턴이거나 attributes 하위에 있을 수 있음
        sizes = self._extract_sizes(product)
        if not sizes:
            skus = product.get("skus", [])
            if isinstance(skus, list):
                labels = [s.get("size") or s.get("sizeLabel") or s.get("displayValue") for s in skus if isinstance(s, dict)]
                sizes = ", ".join(dict.fromkeys(str(l) for l in labels if l))

        return {
            "description": self._extract_description(product),
            "sizes": sizes,
            "image_urls": self._extract_image_urls(product),
            "store_inventory": "",
        }

    # ── 카테고리 목록 추출 ─────────────────────────────────────────────────────

    def _extract_products_from_next_data(self, html: str, category_name: str) -> list[dict]:
        soup = BeautifulSoup(html, "html.parser")
        script = soup.find("script", id="__NEXT_DATA__")
        if not script:
            return []

        try:
            data = json.loads(script.string)
            page_props = data.get("props", {}).get("pageProps", {})

            items: list = []
            if "category" in page_props:
                items = page_props["category"].get("products", [])
            elif "products" in page_props:
                items = page_props["products"]
            elif "searchResult" in page_props:
                items = page_props["searchResult"].get("products", [])
            elif "plpData" in page_props:
                items = page_props["plpData"].get("products", [])

            if not items:
                apollo = data.get("props", {}).get("apolloState", {})
                for key, val in apollo.items():
                    if key.startswith("Product:") and isinstance(val, dict):
                        items.append(val)

            if not items:
                for query in page_props.get("queries", []):
                    if "hits" in query:
                        items.extend(query["hits"])
                    elif "products" in query:
                        items.extend(query["products"])
        except Exception:
            return []

        products = []
        for item in items:
            name = item.get("name") or item.get("title") or item.get("titleInt")
            if not name and "attributes" in item:
                name = item["attributes"].get("name")
            if not name:
                continue

            sku = (
                item.get("sku")
                or item.get("identifier")
                or item.get("style_color_ref")
                or item.get("styleColorRef")
            )
            if not sku and "attributes" in item:
                sku = item["attributes"].get("sku") or item["attributes"].get("identifier")

            price_data = item.get("price")
            if not price_data and "attributes" in item:
                price_data = item["attributes"].get("price")
            if isinstance(price_data, list) and price_data:
                price_data = price_data[0]
            if isinstance(price_data, dict):
                price_val = price_data.get("value") or price_data.get("amount") or price_data.get("price")
            else:
                price_val = price_data

            url_path = item.get("url") or item.get("slug")
            if not url_path and "attributes" in item:
                url_path = item["attributes"].get("url") or (item["attributes"].get("productLink") or {}).get("uri")
            full_url = urljoin(self.BASE_URL, url_path) if url_path else ""

            color_info = item.get("color") or item.get("subtitle") or item.get("variantName")
            if not color_info and "attributes" in item:
                color_info = item["attributes"].get("color") or item["attributes"].get("subtitle")
            if isinstance(color_info, list):
                colors = ", ".join(str(c) for c in color_info)
            elif isinstance(color_info, dict):
                colors = color_info.get("label", "") or color_info.get("name", "")
            else:
                colors = str(color_info) if color_info else ""

            products.append({
                "category": category_name,
                "name": str(name).strip(),
                "price": self._parse_price_value(price_val),
                "url": full_url,
                "reference": str(sku).strip() if sku else "",
                "colors": str(colors).strip(),
            })

        return products

    def _extract_products_from_selectors(self, html: str, category_name: str, category_url: str) -> list[dict]:
        selectors = self.config["selectors"]
        product_card_selector = selectors.get("product_card", "")
        if not product_card_selector:
            return []

        soup = BeautifulSoup(html, "html.parser")
        cards = soup.select(product_card_selector)

        sku_pattern = re.compile(r"[A-Z][0-9]{5}")
        products = []

        for card in cards:
            name_tag = card.select_one(selectors.get("name", ""))
            price_tag = card.select_one(selectors.get("price", ""))
            link_tag = card.select_one(selectors.get("link", ""))

            name = name_tag.get_text(strip=True) if name_tag else ""
            if not name:
                continue

            sku = self._extract_sku_from_card(card, name_tag, link_tag, sku_pattern)

            href = ""
            if link_tag and link_tag.has_attr("href"):
                href = urljoin(category_url, link_tag["href"])
                if href and not href.startswith("http"):
                    href = urljoin(self.BASE_URL, href)

            products.append({
                "category": category_name,
                "name": name,
                "price": parse_price(price_tag) if price_tag else None,
                "url": href,
                "reference": sku,
                "colors": "",
            })

        return products

    def _extract_sku_from_card(self, card, name_tag, link_tag, sku_pattern: re.Pattern) -> str:
        for attr in ["id", "data-sku", "data-id"]:
            match = sku_pattern.search(card.get(attr, ""))
            if match:
                return match.group()

        if name_tag:
            title_tag = name_tag if name_tag.name == "h2" else name_tag.find_parent("h2")
            if title_tag and title_tag.has_attr("id"):
                match = sku_pattern.search(title_tag["id"])
                if match:
                    return match.group()

        if link_tag:
            match = sku_pattern.search(link_tag.get("id", "")) or sku_pattern.search(link_tag.get("href", ""))
            if match:
                return match.group()

        img_tag = card.select_one("img")
        if img_tag:
            src = img_tag.get("src", "") or img_tag.get("data-src", "")
            match = sku_pattern.search(src)
            if match:
                return match.group()

        return ""
