import json
import random
import time
from pathlib import Path
from typing import Optional
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from utils.debug_helper import save_html_snapshot
from utils.helper import scroll_until_lazy_content_loaded


class BaseScraper:
    BASE_URL = ""
    requires_driver = True

    def __init__(self, driver: Optional[webdriver.Chrome], config: dict):
        self.driver = driver
        self.config = config
        self._detail_diag_count = 0

    # ── 템플릿 메서드 (Dior / LV 공통 플로우) ──────────────────────────────────
    # Bottega / Celine 등 다른 플로우가 필요한 스크레이퍼는 이 메서드를 통째로 오버라이드합니다.

    def parse_category(self, category_name: str, url: str) -> list[dict]:
        scraping_settings = self.config.get("scraping_settings", {})
        selectors = self.config["selectors"]

        self._before_navigate(scraping_settings)
        self.driver.get(url)

        try:
            WebDriverWait(self.driver, scraping_settings.get("initial_wait_sec", 20)).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            time.sleep(random.uniform(2.0, 5.0))
        except Exception:
            html = self.driver.page_source
            self._check_html_or_raise(category_name, html, [])
            return []

        self._dismiss_known_popups(scraping_settings)
        time.sleep(random.uniform(1.0, 2.0))

        scroll_result = scroll_until_lazy_content_loaded(
            self.driver,
            pause_time=float(scraping_settings.get("scroll_pause_time", 3.0)),
            product_card_selector=selectors["product_card"],
            placeholder_selector=selectors.get("lazy_placeholder", ""),
            max_loops=int(scraping_settings.get("max_scroll_loops", 20)),
            max_placeholder_retries=int(scraping_settings.get("max_placeholder_retries", 3)),
        )
        time.sleep(2)

        html = self.driver.page_source
        block_reason = self._detect_block_reason(html)
        if block_reason:
            snapshot_path = self._save_snapshot(category_name, html, block_reason)
            raise RuntimeError(f"차단 페이지가 감지되었습니다 ({block_reason}): {snapshot_path}")

        products = self.extract_products_from_html(html, category_name, url)

        max_products = int(scraping_settings.get("max_products_per_category", 0))
        if max_products > 0:
            products = products[:max_products]

        if not products:
            reason = "no_products_with_placeholders" if scroll_result["placeholder_count"] > 0 else "no_products"
            snapshot_path = self._save_snapshot(category_name, html, reason)
            raise RuntimeError(f"상품을 찾지 못했습니다. HTML 저장: {snapshot_path}")

        return products

    def _before_navigate(self, scraping_settings: dict) -> None:
        """Hook: 페이지 이동 직전 처리. 필요한 스크레이퍼에서 오버라이드."""
        pass

    def extract_products_from_html(self, html: str, category_name: str, category_url: str) -> list[dict]:
        raise NotImplementedError

    # ── 상세 페이지 보강 ──────────────────────────────────────────────────────

    def enrich_with_details(
        self,
        products: list[dict],
        on_progress: Optional[callable] = None,
        on_checkpoint: Optional[callable] = None,
    ) -> tuple[list[dict], int]:
        """
        fetch_detail이 true일 때 각 상품 URL을 방문해 상세 정보를 추가합니다.
        반환: (보강된 products, 실패 건수)

        on_progress(current, total, name) — 매 상품마다 호출
        on_checkpoint(products)           — N개마다 호출 (중간 저장용)
          checkpoint 저장 실패(PermissionError 등)는 경고만 출력하고 계속 진행합니다.
        """
        scraping_settings = self.config.get("scraping_settings", {})
        if not scraping_settings.get("fetch_detail", False):
            return products, 0

        delay = float(scraping_settings.get("detail_page_delay_sec", 5.0))
        download_images = scraping_settings.get("download_images", False)
        checkpoint_interval = int(scraping_settings.get("detail_checkpoint_interval", 10))
        brand_id = self.config.get("brand", {}).get("id", "unknown")
        fail_count = 0

        for i, product in enumerate(products):
            if on_progress:
                on_progress(i + 1, len(products), product.get("name", ""))

            url = product.get("url")
            if not url:
                continue

            if i > 0:
                time.sleep(delay * random.uniform(0.8, 1.3))

            try:
                detail = self.parse_detail(url)
                enriched = {k: v for k, v in detail.items() if v}
                if enriched:
                    product.update(enriched)
                else:
                    fail_count += 1

                if i < self._DETAIL_DIAG_LIMIT:
                    self._write_diag(i, url, detail)

                if download_images:
                    image_urls = [u.strip() for u in product.get("image_urls", "").split(",") if u.strip()]
                    if image_urls:
                        from utils.image_downloader import download_product_images, get_image_output_dir
                        ref = product.get("reference") or f"product_{i}"
                        dest = get_image_output_dir(brand_id, ref)
                        local_paths = download_product_images(image_urls, dest, self.driver)
                        if local_paths:
                            product["image_local_paths"] = ", ".join(local_paths)
            except Exception as exc:
                fail_count += 1
                product["_detail_error"] = str(exc)

            # 체크포인트: N개마다 중간 저장 (저장 실패해도 크롤링은 계속)
            if on_checkpoint and (i + 1) % checkpoint_interval == 0:
                try:
                    on_checkpoint(products)
                except Exception:
                    pass

        return products, fail_count

    _DETAIL_DIAG_LIMIT: int = 3

    def _write_diag(self, idx: int, url: str, detail: dict) -> None:
        project_root = Path(self.config.get("project_root", "."))
        brand_id = self.config.get("brand", {}).get("id", "unknown")
        diag_dir = project_root / "tmp_debug" / brand_id
        diag_dir.mkdir(parents=True, exist_ok=True)
        diag_path = diag_dir / f"diag_{idx + 1:02d}.json"
        diag_path.write_text(
            json.dumps({"url": url, "detail": detail}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def parse_detail(self, url: str) -> dict:
        if not self.driver:
            return {}

        self.driver.get(url)
        try:
            WebDriverWait(self.driver, 15).until(
                EC.presence_of_element_located((By.TAG_NAME, "body"))
            )
            lo, hi = self._detail_wait_range()
            time.sleep(random.uniform(lo, hi))
        except Exception:
            return {}

        html = self.driver.page_source
        block_reason = self._detect_block_reason(html)
        if block_reason:
            label = url.rstrip("/").split("/")[-1][:40]
            self._save_snapshot(f"detail_{label}", html, f"detail_{block_reason}")
            return {}

        result = self._parse_detail_from_next_data(html)

        has_next_data = "<script id=\"__NEXT_DATA__\"" in html

        if not result.get("image_urls"):
            result["image_urls"] = self._extract_page_images(html)

        if not result.get("description") or not result.get("sizes"):
            self._fill_from_selectors(html, result)

        if not any(v for v in result.values() if v):
            label = url.rstrip("/").split("/")[-1][:40]
            self._save_snapshot(f"detail_{label}", html, "detail_empty")

        return result

    def _detail_wait_range(self) -> tuple[float, float]:
        """상세 페이지 로딩 대기 범위 (초). 브랜드별로 오버라이드 가능."""
        return (2.0, 3.0)

    def _parse_detail_from_next_data(self, html: str) -> dict:
        """__NEXT_DATA__에서 상세 정보를 추출합니다. 브랜드별로 오버라이드합니다."""
        soup = BeautifulSoup(html, "html.parser")
        script = soup.find("script", id="__NEXT_DATA__")
        if not script:
            return {}

        try:
            data = json.loads(script.string)
            page_props = (data.get("props") or {}).get("pageProps") or {}
        except (json.JSONDecodeError, AttributeError):
            return {}

        product = self._find_detail_product(page_props)
        if not product:
            return {}

        return {
            "description": self._extract_description(product),
            "sizes": self._extract_sizes(product),
            "image_urls": self._extract_image_urls(product),
            "store_inventory": "",
        }

    def _fill_from_selectors(self, html: str, result: dict) -> None:
        """__NEXT_DATA__에서 못 찾은 필드를 CSS 셀렉터로 보완합니다."""
        detail_selectors = self.config.get("detail_selectors", {})
        soup = BeautifulSoup(html, "html.parser")

        if not result.get("description"):
            selector = detail_selectors.get("description", "")
            if selector:
                tag = soup.select_one(selector)
                if tag:
                    result["description"] = tag.get_text(separator=" ", strip=True)

        if not result.get("sizes"):
            selector = detail_selectors.get("sizes", "")
            if selector:
                tags = soup.select(selector)
                sizes = [t.get_text(strip=True) for t in tags if t.get_text(strip=True)]
                result["sizes"] = ", ".join(dict.fromkeys(sizes))

        if not result.get("image_urls"):
            selector = detail_selectors.get("images", "")
            if selector:
                imgs = soup.select(selector)
                urls = [img.get("src") or img.get("data-src", "") for img in imgs]
                result["image_urls"] = ", ".join(u for u in dict.fromkeys(urls) if u.startswith("http"))

    # ── 상세 추출 공통 헬퍼 ───────────────────────────────────────────────────

    def _find_detail_product(self, page_props: dict) -> dict:
        """__NEXT_DATA__.props.pageProps 안에서 상품 상세 객체를 탐색합니다."""
        CANDIDATE_KEYS = ("product", "productDetails", "pdpData", "initialData", "productData")
        INDICATOR_KEYS = {"name", "title", "description", "images", "variants", "media"}

        for key in CANDIDATE_KEYS:
            val = page_props.get(key)
            if not isinstance(val, dict):
                continue
            if INDICATOR_KEYS & val.keys():
                return val
            # 1단계 더 내려가기 (e.g. pdpData.product)
            for subkey in ("product", "productDetails", "productData"):
                sub = val.get(subkey)
                if isinstance(sub, dict) and INDICATOR_KEYS & sub.keys():
                    return sub

        return {}

    def _extract_description(self, product: dict) -> str:
        for key in ("description", "longDescription", "shortDescription", "content", "details"):
            val = product.get(key, "")
            if isinstance(val, str) and val.strip():
                return val.strip()
            if isinstance(val, dict):
                text = val.get("text") or val.get("value") or val.get("content") or ""
                if text:
                    return str(text).strip()
        return ""

    def _extract_sizes(self, product: dict) -> str:
        candidates = (
            product.get("variants")
            or product.get("sizes")
            or product.get("skus")
            or product.get("attributes", {}).get("sizes")
        )
        if not isinstance(candidates, list):
            return ""

        sizes = []
        for item in candidates:
            if isinstance(item, str):
                sizes.append(item)
            elif isinstance(item, dict):
                label = (
                    item.get("size") or item.get("sizeLabel") or item.get("label")
                    or item.get("value") or item.get("name")
                )
                if label:
                    sizes.append(str(label))

        return ", ".join(dict.fromkeys(sizes))  # 순서 유지 중복 제거

    def _extract_image_urls(self, product: dict) -> str:
        urls: list[str] = []

        for key in ("images", "media", "mediaItems", "gallery", "photos"):
            items = product.get(key)
            if not isinstance(items, list):
                continue
            for item in items:
                if isinstance(item, str) and item.startswith("http"):
                    urls.append(item)
                elif isinstance(item, dict):
                    url = (
                        item.get("src") or item.get("url") or item.get("href")
                        or item.get("originalSrc")
                        or (item.get("large") or {}).get("url")
                        or (item.get("medium") or {}).get("url")
                    )
                    if url and isinstance(url, str) and url.startswith("http"):
                        urls.append(url)

        return ", ".join(dict.fromkeys(urls[:10]))  # 최대 10장, 중복 제거

    def _extract_page_images(self, html: str) -> str:
        """og:image, twitter:image, JSON-LD image 등 여러 소스에서 이미지 URL을 수집합니다."""
        soup = BeautifulSoup(html, "html.parser")
        urls: list[str] = []

        for prop in ("og:image", "og:image:url", "og:image:secure_url"):
            for tag in soup.find_all("meta", property=prop):
                url = tag.get("content", "")
                if url and url.startswith("http"):
                    urls.append(url)

        for name in ("twitter:image", "twitter:image:src"):
            for tag in soup.find_all("meta", attrs={"name": name}):
                url = tag.get("content", "")
                if url and url.startswith("http"):
                    urls.append(url)

        for script in soup.select('script[type="application/ld+json"]'):
            try:
                data = json.loads(script.string or script.get_text())
                urls.extend(self._collect_json_ld_images(data))
            except Exception:
                pass

        return ", ".join(dict.fromkeys(u for u in urls if u)[:10])

    def _collect_json_ld_images(self, data, _depth: int = 0) -> list[str]:
        """JSON-LD에서 이미지 URL을 재귀 탐색합니다 (최대 3단계)."""
        if _depth > 3:
            return []
        urls: list[str] = []
        if isinstance(data, dict):
            for key in ("image", "thumbnail", "thumbnailUrl", "logo"):
                val = data.get(key)
                if isinstance(val, str) and val.startswith("http"):
                    urls.append(val)
                elif isinstance(val, list):
                    for item in val:
                        if isinstance(item, str) and item.startswith("http"):
                            urls.append(item)
                        elif isinstance(item, dict):
                            url = item.get("url") or item.get("contentUrl", "")
                            if url and isinstance(url, str) and url.startswith("http"):
                                urls.append(url)
            for val in data.values():
                if isinstance(val, (dict, list)):
                    urls.extend(self._collect_json_ld_images(val, _depth + 1))
        elif isinstance(data, list):
            for item in data:
                urls.extend(self._collect_json_ld_images(item, _depth + 1))
        return urls

    # ── 공통 추출 유틸리티 ────────────────────────────────────────────────────

    def _extract_products_from_json_ld(self, html: str, category_name: str) -> list[dict]:
        soup = BeautifulSoup(html, "html.parser")
        scripts = soup.select('script[type="application/ld+json"]')

        products = []
        for script in scripts:
            raw_text = script.string or script.get_text(strip=True)
            if not raw_text:
                continue
            try:
                payload = json.loads(raw_text)
            except json.JSONDecodeError:
                continue
            for product_data in self._find_product_entries(payload):
                normalized = self._normalize_product(product_data, category_name)
                if normalized:
                    products.append(normalized)

        return products

    def _find_product_entries(self, payload) -> list[dict]:
        found = []
        if isinstance(payload, dict):
            if payload.get("@type") in {"Product", "IndividualProduct", "ProductGroup"}:
                found.append(payload)
            for value in payload.values():
                found.extend(self._find_product_entries(value))
        elif isinstance(payload, list):
            for item in payload:
                found.extend(self._find_product_entries(item))
        return found

    def _normalize_product(self, product_data: dict, category_name: str) -> Optional[dict]:
        name = str(product_data.get("name", "")).strip()
        if not name:
            return None

        offers = product_data.get("offers", {})
        if isinstance(offers, list):
            offers = offers[0] if offers else {}

        raw_price = offers.get("price") if isinstance(offers, dict) else None
        detail_url = product_data.get("url", "") or product_data.get("@id", "")
        if detail_url and not detail_url.startswith("http"):
            detail_url = urljoin(self.BASE_URL, detail_url)

        reference = (
            product_data.get("sku")
            or product_data.get("productID")
            or product_data.get("mpn")
            or ""
        )
        colors = product_data.get("color", "")
        if isinstance(colors, list):
            colors = ", ".join(str(c).strip() for c in colors if str(c).strip())

        return {
            "category": category_name,
            "name": name,
            "price": self._parse_price_value(raw_price),
            "url": detail_url,
            "reference": str(reference).strip(),
            "colors": str(colors).strip(),
        }

    def _deduplicate_by_url(self, products: list[dict]) -> list[dict]:
        seen: set[str] = set()
        result = []
        for product in products:
            url = product.get("url", "")
            if url not in seen:
                seen.add(url)
                result.append(product)
        return result

    def _parse_price_value(self, raw_price) -> Optional[int]:
        if raw_price in (None, ""):
            return None
        digits = "".join(ch for ch in str(raw_price) if ch.isdigit())
        return int(digits) if digits else None

    # ── 봇 차단 감지 / 스냅샷 ────────────────────────────────────────────────

    def _detect_block_reason(self, html: str) -> Optional[str]:
        html_lower = html.lower()

        if "403 forbidden" in html_lower or "error 403" in html_lower:
            return "http_403_forbidden"
        if "access denied" in html_lower:
            if "reference #" in html_lower or "akamai" in html_lower:
                return "akamai_access_denied"
            return "general_access_denied"
        if "g-recaptcha" in html_lower or "cf-turnstile" in html_lower or "hcaptcha" in html_lower:
            return "captcha_challenge"
        if 'id="challenge-form"' in html_lower or 'id="challenge-running"' in html_lower:
            return "cloudflare_challenge"
        if "just a moment" in html_lower and "cloudflare" in html_lower:
            return "cloudflare_wait"
        if "page unavailable" in html_lower and "reference id" in html_lower:
            return "akamai_unavailable"
        if "id=" in html_lower and "ip=" in html_lower and "date/time=" in html_lower:
            return "waf_incident_report"
        if "distil" in html_lower or "imperva" in html_lower or "datadome" in html_lower:
            return "advanced_bot_shield"

        return None

    def _save_snapshot(self, category_name: str, html: str, reason: str) -> Path:
        project_root = Path(self.config.get("project_root", "."))
        brand_id = self.config.get("brand", {}).get("id", "unknown")
        return save_html_snapshot(project_root, brand_id, category_name, html, reason)

    def _check_html_or_raise(self, category_name: str, html: str, products: list) -> None:
        block_reason = self._detect_block_reason(html)
        if block_reason:
            snapshot_path = self._save_snapshot(category_name, html, block_reason)
            raise RuntimeError(f"차단 페이지가 감지되었습니다 ({block_reason}): {snapshot_path}")

        if not products:
            snapshot_path = self._save_snapshot(category_name, html, "no_products")
            raise RuntimeError(f"상품을 찾지 못했습니다. HTML 저장: {snapshot_path}")

    # ── 팝업 처리 ─────────────────────────────────────────────────────────────

    def _dismiss_known_popups(self, scraping_settings: dict) -> None:
        popup_selectors = scraping_settings.get("popup_selectors", [
            "#onetrust-accept-btn-handler",
            "button[aria-label='Close']",
            "button[aria-label='close']",
            "button[class*='close']",
            "button[class*='modal-close']",
        ])
        popup_xpaths = scraping_settings.get("popup_xpaths", [
            "//button[contains(., '동의')]",
            "//button[contains(., 'Accept All')]",
            "//button[contains(., 'Accept')]",
            "//button[contains(., '닫기')]",
        ])

        for selector in popup_selectors:
            try:
                for element in self.driver.find_elements(By.CSS_SELECTOR, selector):
                    if element.is_displayed():
                        element.click()
                        return
            except Exception:
                continue

        for xpath in popup_xpaths:
            try:
                for element in self.driver.find_elements(By.XPATH, xpath):
                    if element.is_displayed():
                        element.click()
                        return
            except Exception:
                continue
