import re

import gspread


SHEET_HEADERS = ["번호", "상품명", "레퍼런스", "색상", "소재", "카테고리", "가격", "사이즈", "설명", "재고매장"]
WRITE_MODE_APPEND = "append"
WRITE_MODE_OVERWRITE = "overwrite"
SUPPORTED_WRITE_MODES = {WRITE_MODE_APPEND, WRITE_MODE_OVERWRITE}
WORKSHEET_INITIAL_ROWS = 5000


def get_spreadsheet(json_key_file: str, spreadsheet_name: str):
    gc = gspread.service_account(filename=json_key_file)
    return gc.open(spreadsheet_name)


def sanitize_sheet_name(name: str) -> str:
    return re.sub(r"[\\/?*\[\]]", "_", name)[:100]


def get_or_create_worksheet(spreadsheet, sheet_name: str):
    sanitized_name = sanitize_sheet_name(sheet_name)
    try:
        worksheet = spreadsheet.worksheet(sanitized_name)
        return worksheet, False
    except gspread.WorksheetNotFound:
        worksheet = spreadsheet.add_worksheet(title=sanitized_name, rows=WORKSHEET_INITIAL_ROWS, cols=len(SHEET_HEADERS))
        return worksheet, True


def _header_range() -> str:
    end_col = chr(ord("A") + len(SHEET_HEADERS) - 1)
    return f"A1:{end_col}1"


def ensure_headers(worksheet) -> None:
    header_row = worksheet.row_values(1)
    if header_row[: len(SHEET_HEADERS)] != SHEET_HEADERS:
        worksheet.update(_header_range(), [SHEET_HEADERS])


def clear_worksheet(worksheet) -> None:
    worksheet.clear()
    worksheet.update(_header_range(), [SHEET_HEADERS])


def append_products_to_sheet(worksheet, products: list[dict], write_mode: str = WRITE_MODE_APPEND) -> int:
    if write_mode not in SUPPORTED_WRITE_MODES:
        supported_modes = ", ".join(sorted(SUPPORTED_WRITE_MODES))
        raise ValueError(f"지원하지 않는 저장 모드입니다: {write_mode} ({supported_modes})")

    if write_mode == WRITE_MODE_OVERWRITE:
        clear_worksheet(worksheet)
    else:
        ensure_headers(worksheet)

    if not products:
        return 0

    rows = [
        [
            "",
            product["name"],
            product["reference"],
            product.get("colors", ""),
            product.get("material", ""),
            product["category"],
            product["price"],
            product.get("sizes", ""),
            product.get("description", ""),
            product.get("store_inventory", ""),
        ]
        for product in products
    ]
    worksheet.append_rows(rows)
    return len(rows)
